/*! A1D WP Accessibility - v0.1.2
 * https://a1d.co/accessibility
 * Copyright (c) 2015; * Licensed GPLv2+ */
( function( window, undefined ) {
	'use strict';


} )( this );
