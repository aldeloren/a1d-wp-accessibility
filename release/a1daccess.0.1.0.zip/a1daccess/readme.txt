=== A1D WP Accessibility ===
Contributors:      Anthony DeLorenzo
Donate link:       a1d.co
Tags: 
Requires at least: 4.1.1
Tested up to:      4.1.1
Stable tag:        0.1.0
License:           GPLv2 or later
License URI:       http://www.gnu.org/licenses/gpl-2.0.html

A WordPress plugin to to encourage content creators to create more accessible content for the differently-abled.

== Description ==



== Installation ==

= Manual Installation =

1. Upload the entire `/accessbility` directory to the `/wp-content/plugins/` directory.
2. Activate A1D WP Accessibility through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 0.1.0 =
* First release

== Upgrade Notice ==

= 0.1.0 =
First Release
